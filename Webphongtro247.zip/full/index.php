<?php 
session_start();
require_once "./mvc/mvc.php";
$core = new Core();

?>
