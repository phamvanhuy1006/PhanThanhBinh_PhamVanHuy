<?php
require_once "./mvc/core/controller.php";
class Ajax extends Controller
{
    public $getModel;

    public function __construct()
    {
        
    }
    // kiểm tra đăng nhập
    public function CheckLogin()
    {
        $this -> getModel = $this -> model("checkloginmodel");
        if (isset($_POST["email"])) {
            $user_email = $_POST["email"];
        }
        if (isset($_POST["pass"])) {
            $user_pass = $_POST["pass"];
        }
        $data = $this -> getModel->check($user_email, $user_pass);
        if($data){
            echo $data;
        }else{
            echo "false";
        }
        
    }
    // đăng ký tài khoản
    public function CheckRegis(){
        $this -> getModel = $this -> model("checkregistermodel");
        if (isset($_POST["json_regis"])) {
            $json_regis = $_POST["json_regis"];
        }
        $email = $this -> getModel->check_email($json_regis["email"]);
        if($email){
            $insert_user = $this -> getModel -> insert_user($json_regis["email"], password_hash($json_regis["pass"], PASSWORD_DEFAULT));
            if($insert_user){
                $user_id = $this -> getModel -> get_user_id($json_regis["email"]);
                $insert_infor = $this->getModel->insert_infor($user_id,$json_regis["first_name"], $json_regis["last_name"], $json_regis["birthday"], $json_regis["gender"]);
                if($insert_infor){
                    echo "true";
                    return;
                }else{
                    echo "Vui lòng kiểm tra lại thông tin";
                    return;
                }
            }else{
                echo "Vui lòng kiểm tra lại thông tin";
                return;
            }
        }
        echo "Email đã tồn tại trong hệ thống";
    }
    //thích phòng trọ
    public function LikeRoom(){
        $this -> getModel = $this -> model("updateRoom");
        if(isset($_SESSION['user_id'])){
            if(isset($_POST["room_id"])){
                $room_id = $_POST["room_id"];
            }
            $data = $this -> getModel->like($room_id, $_SESSION['user_id']);
            if($data){
                echo $data;
            }else{
                echo false;
            }
        }else{
            echo "login";
        }
    }
    // bình luận phòng trọ
    public function CmtRoom(){
        $this -> getModel = $this -> model("updateRoom");
        if(isset($_SESSION['user_id'])){
            if(isset($_POST["room_id"])){
                $room_id = $_POST["room_id"];
            }
            if(isset($_POST["content"])){
                $content = $_POST["content"];
            }
            $data = $this -> getModel->addComment($_SESSION['user_id'], $room_id, $content);
            if($data){
                echo $data;
            }else{
                echo false;
            }
        }else{
            echo "login";
        }
    }
}
