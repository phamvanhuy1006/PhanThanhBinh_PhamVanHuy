<?php
//require_once "./mvc/views/blocks/404.php";
require_once "./mvc/core/controller.php";

$controller = new Controller();
$controller -> Error();

?>