<?php
require_once "./mvc/core/controller.php";
class Home extends Controller
{

    function __construct()
    {
    }

    function index()
    {
        $main = ["index_new", "index_heightL", "index_goodRV"];
        $main_left = ["index_mainL"];
        $data = [
            "sshow" => "slideshow_header",
            "main" => $main,
            "main_left" => $main_left
            ];
        $data = json_encode($data);
        $this->view("master_layout", ["data" => $data]);
    }
}
