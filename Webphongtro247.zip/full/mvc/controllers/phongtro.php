<?php
require_once "./mvc/core/controller.php";
class Phongtro extends Controller
{
    public $getModel;
    
    public function __construct()
    {
        $this -> getModel = $this -> model("getRoom");
    }

    function index()
    {
        $main = ["zoom_info", "zoom_main"];
        $main_left = ["zoom_inforVD"];
        $main_ft = ["zoom_similar"];
        $this->view("master_layout", [
            "bread" => "breadcrumb",
            "main" => $main,
            "main_left" => $main_left,
            "main_ft" => $main_ft
            ]);
    }
    function chitietphongtro($id)
    {
        $dataRoom = $this -> getModel->getData($id, "room", "id_room");
        $dataAdd = $this -> getModel->getData($id, "address", "id_add");
        $dataCmt = $this -> getModel->getDataCmt($id);
        $datainfor = $this -> getModel->getData($id, "info_room", "id_infor");
        $dataLike = $this -> getModel->getData($id, "room_like", "id_like");
        if(isset($_SESSION['user_id'])){
            $dataUVote = $this -> getModel->getUVote($id,$_SESSION['user_id']);
        }else{
            $dataUVote = false;
        }
        $dataVendor = $this -> getModel->getDataVendor($id);
        $dataIdVendor = $this -> getModel -> getIdVendor($id);
        $dataCountVote = $this -> getModel->getCountVote($id);
        $dataVoteStar = [
            "v1s" => $this -> getModel->getCountVoteS($id, 1),
            "v2s" => $this -> getModel->getCountVoteS($id, 2),
            "v3s" => $this -> getModel->getCountVoteS($id, 3),
            "v4s" => $this -> getModel->getCountVoteS($id, 4),
            "v5s" => $this -> getModel->getCountVoteS($id, 5),
            ];
        $dataVoteStar = json_encode($dataVoteStar);
        $dataCountLike = $this -> getModel->getCountlike($id);
        $dataULike = $this -> getModel->getULike($id,$_SESSION['user_id']);
        $main = ["zoom_info", "zoom_main"];
        $main_left = ["zoom_inforVD"];
        $main_ft = ["zoom_similar"];
        $data = [
            "bread" => "breadcrumb",
            "main" => $main,
            "main_left" => $main_left,
            "main_ft" => $main_ft,
            "vendor" => $dataVendor,
            "idVendor" => $dataIdVendor,
            "room" => $dataRoom,
            "address" => $dataAdd,
            "comment" => $dataCmt,
            "infor" => $datainfor,
            "like" => $dataLike,
            "voteU" => $dataUVote,
            "voteCount" => $dataCountVote,
            "voteStar" => $dataVoteStar,
            "countLike" => $dataCountLike,
            "likeU"=>$dataULike
            ];
            $data = json_encode($data);
        $this->view("master_layout", ["data" => $data]);
    }
}
