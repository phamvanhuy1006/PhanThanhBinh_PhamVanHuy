<?php
require_once "./mvc/core/controller.php";
class Timkiem extends Controller
{

    function __construct()
    {
    }

    function index()
    {
        $main = ["search_main"];
        $main_left = ["zoom_inforVD"];
        $main_ft = [];
        $this->view("master_layout", [
            "bread" => "breadcrumb",
            "main" => $main,
            "main_left" => $main_left,
            "main_ft" => $main_ft
            ]);
    }
    function timkiem($id)
    {
        $main = ["search_main"];
        $main_left = ["zoom_inforVD"];
        $main_ft = [];
        $this->view("master_layout", [
            "bread" => "breadcrumb",
            "main" => $main,
            "main_left" => $main_left,
            "main_ft" => $main_ft
            ]);
    }
}
