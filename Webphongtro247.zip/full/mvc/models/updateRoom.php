<?php
require_once "./mvc/core/config.php";
class updateRoom extends Config
{
    public function like($room_id, $user_id){
        $check = $this -> CheckUserLike($room_id, $user_id);
        if($check){
            $action = $this -> RemoveLike($room_id, $user_id);
            $count = $this -> getCountlike($room_id);
            $data = [
                "action" => $action,
                "count" => $count
                ];
            return json_encode($data);
        }else{
            $action = $this -> AddLike($room_id, $user_id);
            $count = $this -> getCountlike($room_id);
            $data = [
                "action" => $action,
                "count" => $count
                ];
            return json_encode($data);
        }
    }
    public function AddLike($room_id, $user_id){
        $query = "INSERT INTO `room_like`(`user_id`, `room_id`) VALUES ('$user_id','$room_id')";
        $result = mysqli_query($this->connect, $query);
        if($result){
            return "add";
        }else{
            return false;
        }
    }
    public function RemoveLike($room_id, $user_id){
        $query = "DELETE FROM `room_like` WHERE `user_id` = $user_id AND `room_id` = $room_id";
        $result = mysqli_query($this->connect, $query);
        if($result){
            return "remove";
        }else{
            return false;
        }
    }
    public function CheckUserLike($room_id, $user_id){
        $query = "SELECT COUNT(`id_like`) AS id_like FROM `room_like` WHERE `user_id` = $user_id AND `room_id` = $room_id GROUP BY `id_like`";
        $result = mysqli_query($this->connect, $query);
        while ($row  = mysqli_fetch_array($result)) {
            $dataRoom =  $row["id_like"];
        }
        if($dataRoom < 1){
            return false;
        }else{
            return true;
        }
    }
    public function getCountlike($roomId){
        $query = "SELECT COUNT(*) as room_id FROM room_like WHERE room_id = $roomId GROUP BY room_id";
        $result = mysqli_query($this->connect, $query);
        while ($row  = mysqli_fetch_array($result)) {
            $data= $row["room_id"];
        }
        return $data;
    }
    public function addComment($user_id, $room_id, $content){
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $time = date('Y-m-d H:i:s');
        $query = "INSERT INTO `comment`(`user_id`, `room_id`, `cmt_content`, `cmt_time`) VALUES ($user_id, $room_id,'$content','$time')";
        $result = mysqli_query($this->connect, $query);
        $idCmt = $this -> getMaxIdCmt();
        if($result){
            return $idCmt;
        }else{
            return false;
        }
    }
    public function getMaxIdCmt(){
        $query = "SELECT MAX(`id_comment`) AS id_comment FROM `comment`";
        $result = mysqli_query($this->connect, $query);
        while ($row  = mysqli_fetch_array($result)) {
            $data= $row["id_comment"] + 1;
        }
        return $data;
    }
}