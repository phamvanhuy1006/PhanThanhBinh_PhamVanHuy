<?php 
require_once "./mvc/core/core.php";

require_once "./mvc/core/controller.php";

require_once "./mvc/core/config.php";



?>
