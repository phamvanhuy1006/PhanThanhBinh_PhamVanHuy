<script src="/public/js/jquery/jquery-3.5.1.min.js"></script>
<script src="/public/js/bootstrap/bootstrap.bundle.min.js"></script>
<script src="/public/owlcarousel/owl.carousel.min.js"></script>
<script src="/public/fontawesome/js/all.min.js"></script>
<!--  -->
<script src="/public/js/js.js"></script>
<script src="/public/js/ajax.js"></script>

