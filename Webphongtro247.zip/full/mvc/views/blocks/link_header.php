<link rel="stylesheet" href="/public/css/bootstrap/bootstrap.css">
<link rel="stylesheet" href="/public/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/public/owlcarousel/assets/owl.theme.default.min.css">
<!--  -->
<link rel="stylesheet" href="/public/fontawesome/css/all.min.css">
<link rel="stylesheet" href="/public/css/style.css">
