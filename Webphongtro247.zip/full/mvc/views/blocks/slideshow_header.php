<div class="position-relative full_slide_show_header">
    <!--sile show-->
    <section id="slide_show_header" class="preloading">
        <div id="carouselExampleInterval" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active" data-interval="5000">
              <img src="./public/upload/image/slideshow1.jpg" class="d-block w-100 " alt="...">
            </div>
            <div class="carousel-item" data-interval="5000">
              <img src="./public/upload/image/slideshow2.jpg" class="d-block w-100" alt="...">
            </div>
          </div>
        </div>
    </section>
    <!--box search-->
    <section id="box_search_header" class="position-absolute header_bs_slideshow text-center w-100 h-100 preloading">
        <div class="text-left d-inline-block">
            <h2 class="text-white slg_search">Tìm trọ nhanh chóng - vừa ý</h2>
            <div class="d-flex">
                <div id="form_search" class="bg-colorbsop p-3 rounded">
                    <div class="input-group mb-1">
                        <input type="text" class="form-control" placeholder="Từ khóa tìm kiếm (có thể để trống)"  aria-describedby="button-addon4">
                        <div class="input-group-append" id="button-addon4">
                            <button class="btn btn-colorbgw" type="button">
                                <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-search" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" d="M10.442 10.442a1 1 0 0 1 1.415 0l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1 0-1.415z"/>
                                  <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z"/>
                                </svg>
                            </button>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="input-group">
                            <select class="custom-select col" id="inputGroupSelect01">
                                <option selected>Điều kiện</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            <select class="custom-select col" id="inputGroupSelect01">
                                <option selected>Khoảng giá</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            <select class="custom-select col" id="inputGroupSelect01">
                                <option selected>Diện tích</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                            <select class="custom-select col" id="inputGroupSelect01">
                                <option selected>Loại phòng</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="bg-colorbsop p-3 rounded ml-1 review_now_slideshow_header">
                    <p class="text-white">Đánh giá khu vực bạn ở.</p>
                    <button class="btn btn-colorbgw w-100">
                        Đánh giá ngay
                    </button>
                </div>
            </div>
            
        </div>
    </section>
</div>