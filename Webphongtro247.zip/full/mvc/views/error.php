<?php 
    require_once "./mvc/views/blocks/".$data["404"].".php";
?>