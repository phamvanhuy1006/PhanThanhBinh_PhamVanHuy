<nav aria-label="breadcrumb">
    <ol class="breadcrumb py-0 rounded-0 mb-1">
        <li class="breadcrumb-item"><a class="text-decoration-none text-colors" href="#">Home</a></li>
        <li class="breadcrumb-item"><a class="text-decoration-none text-colors" href="#">Library</a></li>
        <li class="breadcrumb-item active" aria-current="page">Data</li>
    </ol>
</nav>