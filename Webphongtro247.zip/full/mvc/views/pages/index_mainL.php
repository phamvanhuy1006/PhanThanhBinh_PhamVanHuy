<section class="main_left_local border rounded ml-1 sticky-top-50">
    <ul class="list-group">
        <li class="list-group-item bg-colors text-white font-weight-bold text-uppercase pl-2">Theo khu vực</li>
        <a href="#" class="list-group-item list-group-item-action p-1 pl-2">Cras justo odio</a>
        <a href="#" class="list-group-item list-group-item-action p-1 pl-2">Dapibus ac facilisis in</a>
        <a href="#" class="list-group-item list-group-item-action p-1 pl-2">Morbi leo risus</a>
        <a href="#" class="list-group-item list-group-item-action p-1 pl-2">Porta ac consectetur ac</a>
        <a href="#" class="list-group-item list-group-item-action p-1 pl-2">Vestibulum at eros</a>
    </ul>
</section>