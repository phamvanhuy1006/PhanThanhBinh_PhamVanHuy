// kiểm tra đăng nhập
function checklogin() {
    $("#btn_login").click(function() {
        $user_email = $("#user_email").val();
        $user_pass = $("#user_pass").val();
        $.post("/ajax/checklogin", {
            email: $user_email,
            pass: $user_pass
        }, function(data) {
                if(data == "user"){
                    $(location).attr('href', 'https://phongtro247.xyz')
                }else{
                    alert("Tài khoản hoặc mật khẩu không chính xác");
                }
        });
    });
}
window.onload = checklogin();
// đăng ký tài khoản
function register() {
    $("#btn_regis").click(function() {
        $action = true;
        $birthday = $("#regis_bdyear").val() + "-" + $("#regis_bdd").val() + "-" + $("#regis_bdday").val();
        $pass = $("#regis_pass").val();
        $passa = $("#regis_passa").val();
        $gender = "";
        for ($i = 0; $i < 3; $i++) {
            if ($(':radio')[$i].checked) {
                if ($i === 0) {
                    $gender = "Nữ";
                }
                if ($i == 1) {
                    $gender = "Nam";
                }
                if ($i == 2) {
                    $gender = "Khác";
                }
            }
        }
        if (!checkNull([$("#first_name").val(), $("#first_name").val(), $("#first_name").val(), $("#regis_email").val(), $("#regis_pass").val(), $gender])) {
            $action = false;
        }
        if ($pass != $passa) {
            $action = false;
        }
        if(!checkemail($("#regis_email").val())){
            $action = false;
        }
        $json_regis = {
            first_name: $("#first_name").val(),
            last_name: $("#last_name").val(),
            email: $("#regis_email").val(),
            pass: $("#regis_pass").val(),
            birthday: $birthday,
            gender: $gender
        }
        if($action){
            $.post("/ajax/checkregis", {json_regis: $json_regis}, 
            function(data){
                if(data == "true"){
                    $conf = confirm("Đăng ký thành công đăng nhập ngay");
                    if($conf){
                        $user_email = $("#regis_email").val();
                        $user_pass = $("#regis_pass").val();
                        $.post("./ajax/checklogin", {
                            email: $user_email,
                            pass: $user_pass
                        }, function(data) {
                            if(data == "user"){
                                $(location).attr('href', 'https://phongtro247.xyz')
                            }else{
                                alert("Tài khoản hoặc mật khẩu không chính xác");
                            }
                                
                        });
                    }
                }else{
                    alert(data);
                }
            });
            
        }
    });
}
window.onload = register();

$("#likeRoom").click(function(){
    $url = $(location).attr('href');
    $lUrl = $url.lastIndexOf("/");
    $room_id = $url.substr($lUrl + 1, $url.length - 1);
    $room_id = Number($room_id);
    $.post("/ajax/likeroom", {
            room_id: $room_id
        }, function(data) {
            if(data){
                if(data == "login"){
                    $login = confirm("Vui lòng đăng nhập để thực hiện hành động");
                    if($login){
                        $(location).attr('href', 'https://phongtro247.xyz/login');
                    }
                }else{
                    $json = JSON.parse(data);
                    $("#countLikeRoom").html($json.count);
                    if($json.action == "add"){
                        $("#likeRoom svg").addClass("text-danger");
                    }
                    if($json.action == "remove"){
                        $("#likeRoom svg").removeClass("text-danger");
                    }
                }
                
            }else{
                alert("Không thể thực hiện hành động");
            }
        });
});
// bình luận phòng trọ
$("#btnSubCmt").click(function (){
    $cls = $("#boxCmt").attr("class"); 
    $content = $("#boxCmt").val();
    $start = $cls.lastIndexOf("_") + 1;
    $end = $cls.length;
    $id_room = $cls.slice($start, $end);
    $.post("/ajax/CmtRoom", {
        room_id: $id_room,
        content: $content
    }, function(data){
        $("#listCmtRoom").prepend(data);
    })
    
    
});